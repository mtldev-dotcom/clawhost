# NestAI — Brand Guidelines

## App Name
NestAI
- Domains: nestai.app / app.nestai.app / user.nestai.app
- Tagline options:
  - "Your AI. Running 24/7."
  - "One click. Always on."
  - "Set it up once. Let it run."

## Logo
- Wordmark: NestAI — weight 500, letter-spacing -0.03em
- Mark: shield/nest shape, black fill, white inner dot
- Dark bg: white mark + white wordmark
- Light bg: black mark + black wordmark
- Never stretch, recolor, or add effects

## Colors
| Name    | Hex     | Usage                                    |
|---------|---------|------------------------------------------|
| Ink     | #0A0A0A | CTAs, logo, high-emphasis text           |
| Chalk   | #F7F7F5 | Page backgrounds, card surfaces          |
| Mint    | #E8F5F0 | Success backgrounds, subtle fills        |
| Emerald | #1D9E75 | Single accent — status, active, CTA only |
| White   | #FFFFFF | Primary surface                          |

Rules:
- Emerald appears ONCE per screen maximum
- Never use Emerald decoratively
- No other colors. Ever.

## Typography
| Role    | Size | Weight | Tracking          |
|---------|------|--------|-------------------|
| Display | 32px | 500    | -0.03em           |
| Heading | 22px | 500    | -0.02em           |
| Body    | 16px | 400    | 0                 |
| Label   | 12px | 500    | +0.07em uppercase |

- Font: Geist (preferred) or Inter
- Two weights only: 400 and 500. Never 600 or 700.
- Sentence case always — no ALL CAPS, no Title Case in body

## Spacing System
4 — 8 — 12 — 16 — 24 — 32 — 48 — 64px

- Page padding: 24px mobile / 48px desktop
- Section gaps: 64px
- Card padding: 24px
- Component gaps: 8–16px

## Mobile Rules
- Design at 390px first, always
- Minimum tap target: 44px
- No horizontal scroll
- Bottom-anchored CTAs on mobile
- Full-width buttons on mobile

## Component Rules
- Border radius: 8px (small) / 12px (cards) / 20px (pills)
- Borders: 0.5px solid #E8E8E4
- No drop shadows
- No gradients
- No blur / glassmorphism
- White or chalk surfaces only — no dark cards

## Motion
- Transitions: 150ms ease
- Opacity + translate only
- No bounces or spring animations
- Nothing over 200ms

## Voice & Tone
Direct. Calm. No hype.

DO:   "Your agent is live."
NOT:  "Congratulations! Your AI has been successfully deployed!"

DO:   "Paste your Telegram token."
NOT:  "Please provide your API token to proceed with configuration."

DO:   "Something went wrong."
NOT:  "An unexpected error has occurred. Please try again later."

DO:   "Connected."
NOT:  "Successfully connected!"

Rules:
- Short sentences
- No exclamation marks in UI
- Active voice
- No jargon

## Never Do
- Gradients
- Box shadows or drop shadows
- More than 2 font weights
- More than 1 accent color per screen
- ALL CAPS body text
- Exclamation marks in UI copy
- Animations over 200ms
- Horizontal scroll on mobile

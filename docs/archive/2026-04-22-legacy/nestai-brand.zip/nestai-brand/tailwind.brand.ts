import type { Config } from 'tailwindcss'

// NestAI brand tokens
const config: Config = {
  darkMode: ['class'],
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0A0A0A',
        chalk: '#F7F7F5',
        mint: '#E8F5F0',
        emerald: {
          DEFAULT: '#1D9E75',
          light: '#E8F5F0',
          dark: '#0F6E56',
        },
        border: '#E8E8E4',
      },
      fontFamily: {
        sans: ['Geist', 'Inter', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        display: ['32px', { lineHeight: '1.1', letterSpacing: '-0.03em', fontWeight: '500' }],
        heading: ['22px', { lineHeight: '1.2', letterSpacing: '-0.02em', fontWeight: '500' }],
        body:    ['16px', { lineHeight: '1.7', letterSpacing: '0' }],
        label:   ['12px', { lineHeight: '1.4', letterSpacing: '0.07em' }],
      },
      spacing: {
        // Brand spacing scale
        '18': '72px',
      },
      borderRadius: {
        sm:   '8px',
        md:   '12px',
        pill: '20px',
        lg:   '16px',
        xl:   '24px',
      },
      borderWidth: {
        DEFAULT: '0.5px',
      },
      transitionDuration: {
        DEFAULT: '150ms',
      },
      transitionTimingFunction: {
        DEFAULT: 'ease',
      },
      maxWidth: {
        content: '640px',
      },
    },
  },
  plugins: [],
}

export default config

# NestAI — Brand Instructions for Claude Code

## App name
NestAI (not ClawHost — this is the public-facing brand)

## When building any UI component or page, follow these rules without exception:

### Colors — only these 5
- Ink:     #0A0A0A  → CTAs, logo, high-emphasis text
- Chalk:   #F7F7F5  → backgrounds, surfaces
- Mint:    #E8F5F0  → success bg, subtle fills
- Emerald: #1D9E75  → ONE accent per screen, status/active only
- White:   #FFFFFF  → primary surface

### Typography
- Font: Geist via `next/font/google`, fallback Inter
- Weights: 400 (body) and 500 (headings) ONLY — never 600 or 700
- Display: 32px / 500 / tracking -0.03em
- Heading: 22px / 500 / tracking -0.02em
- Body:    16px / 400 / line-height 1.7
- Label:   12px / 500 / tracking +0.07em / uppercase
- Sentence case everywhere — no ALL CAPS, no Title Case

### Spacing
Use only: 4, 8, 12, 16, 24, 32, 48, 64px
- Page padding: 24px mobile / 48px desktop
- Section gaps: 64px
- Cards: 24px padding

### Components
- Border radius: 8px small, 12px cards, 20px pills
- Borders: 0.5px solid #E8E8E4
- NO shadows (no box-shadow, no drop-shadow)
- NO gradients
- NO blur or glassmorphism
- Buttons: full-width on mobile, min-height 44px

### Mobile
- Design 390px first — always
- No horizontal scroll
- Min tap target 44px
- CTAs anchored to bottom on mobile screens

### Motion
- 150ms ease only
- opacity + translateY only
- Nothing over 200ms

### Copy / UI text
- No exclamation marks
- Short sentences
- Active voice
- "Your agent is live." not "Successfully deployed!"

## Import brand tokens
- CSS vars: `import '@/styles/brand.css'`
- Tailwind config: merge with `tailwind.brand.ts`

## shadcn/ui overrides
When using shadcn components, override their default tokens:
- Primary: #0A0A0A
- Ring: #1D9E75
- Radius: 8px
- No shadows on any component
